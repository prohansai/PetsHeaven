// import React, { useState } from 'react';
// import Navbar from './components/Navbar';
// import Home from './components/Home';
// import AvailablePets from './components/AvailablePets';
// import AdoptionProcess from './components/AdoptionProcess';
// import Donate from './components/Donate';
// import ContactUs from './components/ContactUs';
// import Login from './components/Login';

// const App = () => {
//   const [currentSection, setCurrentSection] = useState('home');

//   const renderSection = () => {
//     switch (currentSection) {
//       case 'home':
//         return <Home setCurrentSection={setCurrentSection} />; // Pass setCurrentSection here
//       case 'availablePets':
//         return <AvailablePets />;
//       case 'adoptionProcess':
//         return <AdoptionProcess />;
//       case 'donate':
//         return <Donate />;
//       case 'contactUs':
//         return <ContactUs />;
//       case 'login':
//         return <Login />;
//       default:
//         return <Home setCurrentSection={setCurrentSection} />; // Pass setCurrentSection here
//     }
//   };

//   return (
//     <div className="App">
//       <Navbar setCurrentSection={setCurrentSection} />
//       {renderSection()}
//     </div>
//   );
// };

// export default App;
//--------------------------------------------------------------------------end of working--------------------------------------------------------------//


import React, { useState } from 'react';
import Navbar from './components/Navbar';
import Home from './components/Home';
import AvailablePets from './components/AvailablePets';
import AdoptionProcess from './components/AdoptionProcess';
import Donate from './components/Donate';
import ContactUs from './components/ContactUs';
import Login from './components/Login';

const App = () => {
  const [currentSection, setCurrentSection] = useState('home');

  const renderSection = () => {
    switch (currentSection) {
      case 'home':
        return <Home setCurrentSection={setCurrentSection} />;
      case 'availablePets':
        return <AvailablePets />;
      case 'adoptionProcess':
        return <AdoptionProcess />;
      case 'donate':
        return <Donate />;
      case 'contactUs':
        return <ContactUs />;
      case 'login':
        return <Login />;
      default:
        return <Home setCurrentSection={setCurrentSection} />;
    }
  };

  return (
    <div className="App">
      <Navbar currentSection={currentSection} setCurrentSection={setCurrentSection} />
      {renderSection()}
    </div>
  );
};

export default App;


