import React from 'react';
import './Donate.css'; // Importing the CSS file for styling

const Donate = () => {
  return (
    <div id="donate" className="donate-section">
      <h2>Donate</h2>
      <p>Your contributions help us care for pets in need. Thank you for your generosity!</p>
      
      {/* Adding an image to the donate page */}
      <img
        src="https://www.shutterstock.com/image-vector/adorable-pets-holds-empty-bowls-600nw-2290215819.jpg" // Replace with the actual URL of your image
        alt="Donate to help pets"
        className="donate-image"
      />

      <button className="donate-button">Donate Now</button> {/* Button can link to a payment page */}
    </div>
  );
};

export default Donate;
