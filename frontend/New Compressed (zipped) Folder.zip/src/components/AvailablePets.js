// src/components/AvailablePets.js
import React from 'react';
import { pets, ownerContacts } from '../data'; // Importing pets and owner contacts

const AvailablePets = () => {
  return (
    <div id="available-pets" className="section">
      <h2>Available Pets</h2>
      <div className="pets-list">
        {pets.map((pet) => (
          <div key={pet.id} className="pet-card">
            <img src={pet.image} alt={pet.name} />
            <h3>{pet.name}</h3>
            <p>Breed: {pet.breed}</p>
            <p>Age: {pet.age}</p>
            <p>{pet.description}</p>
            {/* Link to open email client */}
            <a href={`mailto:${ownerContacts[pet.id].email}`}>Contact Owner</a>
          </div>
        ))}
      </div>
    </div>
  );
};

export default AvailablePets;

