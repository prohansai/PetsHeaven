// src/components/Login.js
import React, { useState } from 'react';
import './Login.css'; // Import the CSS file for styling

const Login = () => {
  const [isLogin, setIsLogin] = useState(true); // State to toggle between Login and Signup

  const handleToggle = () => {
    setIsLogin(!isLogin);
  };

  return (
    <div id="login" className="login-section">
      <h2>{isLogin ? 'Login' : 'Sign Up'}</h2>
      <form>
        <label>Email:</label>
        <input type="email" required />
        <label>Password:</label>
        <input type="password" required />
        {!isLogin && (
          <>
            <label>Confirm Password:</label>
            <input type="password" required />
          </>
        )}
        <button type="submit">{isLogin ? 'Login' : 'Sign Up'}</button>
      </form>
      <p>
        {isLogin ? 'Don\'t have an account?' : 'Already have an account?'}
        <span onClick={handleToggle} className="toggle-link">
          {isLogin ? ' Sign Up' : ' Login'}
        </span>
      </p>
    </div>
  );
};

export default Login;
