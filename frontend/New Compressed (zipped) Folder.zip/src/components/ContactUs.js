import React from 'react';
import './ContactUs.css'; // Importing the CSS file for this component

const ContactUs = () => {
  return (
    <div id="contact-us" className="contact-section">
      <h2>Contact Us</h2>
      <p>Email: support@petsheaven.com</p>
      {/* <p>Phone: 123-456-7890</p> */}
      <form className="contact-form">
        <label>Name:</label>
        <input type="text" required /><br />
        
        <label>Email:</label>
        <input type="email" required /><br />
        
        <label>Message:</label>
        <textarea required></textarea><br />
        
        <button type="submit">Send Message</button>
      </form>
    </div>
  );
};

export default ContactUs;

