
// import React from 'react';
// const Navbar = ({ setCurrentSection }) => {
//   return (
//     <nav className='nav'>
        
//       <ul>
//         <li onClick={() => setCurrentSection('home')}>Home</li>
//         <li onClick={() => setCurrentSection('availablePets')}>Available Pets</li>
//         <li onClick={() => setCurrentSection('adoptionProcess')}>Adoption Process</li>
//         <li onClick={() => setCurrentSection('donate')}>Donate</li>
//         <li onClick={() => setCurrentSection('contactUs')}>Contact Us</li>
//         <li onClick={() => setCurrentSection('login')}>Login</li>
//       </ul>
//     </nav>
//   );
// };

// export default Navbar;




// for displaying active section on navbar
import React from 'react';
import './Navbar.css'
const Navbar = ({ currentSection, setCurrentSection }) => {
  return (
    <nav className="nav">
      <ul>
        <li 
          className={currentSection === 'home' ? 'active' : ''}
          onClick={() => setCurrentSection('home')}
        >
          Home
        </li>
        <li 
          className={currentSection === 'availablePets' ? 'active' : ''}
          onClick={() => setCurrentSection('availablePets')}
        >
          Available Pets
        </li>
        <li 
          className={currentSection === 'adoptionProcess' ? 'active' : ''}
          onClick={() => setCurrentSection('adoptionProcess')}
        >
          Adoption Process
        </li>
        <li 
          className={currentSection === 'donate' ? 'active' : ''}
          onClick={() => setCurrentSection('donate')}
        >
          Donate
        </li>
        <li 
          className={currentSection === 'contactUs' ? 'active' : ''}
          onClick={() => setCurrentSection('contactUs')}
        >
          Contact Us
        </li>
        <li 
          className={currentSection === 'login' ? 'active' : ''}
          onClick={() => setCurrentSection('login')}
        >
          Login
        </li>
      </ul>
    </nav>
  );
};

export default Navbar;

